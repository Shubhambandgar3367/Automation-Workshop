Req.
- JDK 17
- Maven 3.8.8
- https://youtu.be/WASIyomqarc
